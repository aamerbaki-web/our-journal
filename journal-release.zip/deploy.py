"""Update the couple's app from Cloud Shell while preserving manual security edits."""
import hashlib
import json
import re
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path

PROJECT = "amer-dania"
BASE = "https://firebaserules.googleapis.com/v1/"
PREVIOUS_RULES = "5e0cd9749a2f8be88f63e87865c5a4190583675a1658b5bee2192f24f917569b"


def fingerprint(source):
    normalized = source.replace("\r\n", "\n").rstrip("\n") + "\n"
    return hashlib.sha256(normalized.encode()).hexdigest()


def read_rules(token):
    def fetch(resource):
        request = urllib.request.Request(BASE + resource, headers={"Authorization": "Bearer " + token})
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.load(response)

    release = fetch(f"projects/{PROJECT}/releases/cloud.firestore")
    name = release["rulesetName"]
    if not re.fullmatch(r"projects/(amer-dania|927848544715)/rulesets/[\w-]+", name):
        sys.exit("تعذّر التعرّف على قواعد هذا المشروع.")
    sources = fetch(name)["source"]["files"]
    if len(sources) != 1 or not isinstance(sources[0].get("content"), str):
        sys.exit("تتضمن قواعد فايربيس الحالية ملفات إضافية. راجعها قبل التحديث.")
    return fingerprint(sources[0]["content"])


def deploy():
    directory = Path(__file__).resolve().parent
    candidate = fingerprint((directory / "dist/setup/firestore.rules").read_text())
    token = subprocess.check_output(["gcloud", "auth", "print-access-token"], text=True).strip()
    try:
        live = read_rules(token)
    except urllib.error.HTTPError as error:
        sys.exit(f"تعذّر التحقّق من قواعد فايربيس الحالية ({error.code}).")
    if live not in {PREVIOUS_RULES, candidate}:
        sys.exit("قواعد الحماية الحالية مختلفة عن الإصدارين المعروفين. توقّف النشر حتى تتم مراجعتها. " + live)
    target = "hosting" if live == candidate else "firestore:rules,hosting"
    subprocess.run(["firebase", "deploy", "--only", target, "--project", PROJECT], cwd=directory, check=True)


if __name__ == "__main__":
    deploy()
